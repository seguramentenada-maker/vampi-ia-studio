const socket = io();
socket.on("online-count", count => document.getElementById("onlineCount").textContent = count);

fetch("/api/status").then(r => r.json()).then(data => {
  document.getElementById("serviceStatus").textContent = data.service;
  document.getElementById("statusText").textContent = `${data.service} · Operativo`;
}).catch(() => {
  document.getElementById("serviceStatus").textContent = "OFFLINE";
  document.getElementById("statusText").textContent = "No disponible";
});

const fileInput = document.getElementById("modelFile");
fileInput.addEventListener("change", () => {
  document.getElementById("fileName").textContent = fileInput.files[0]?.name || "Ningún archivo seleccionado";
});

document.getElementById("uploadForm").addEventListener("submit", async e => {
  e.preventDefault();
  const msg = document.getElementById("uploadMessage");
  if (!fileInput.files.length) return;
  msg.textContent = "Subiendo archivo…";
  const body = new FormData();
  body.append("model", fileInput.files[0]);
  try {
    const response = await fetch("/api/upload", { method: "POST", body });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    msg.innerHTML = `${data.message} <a href="${data.downloadUrl}" style="color:#ff5265">Descargar archivo</a>`;
  } catch (err) { msg.textContent = err.message || "Error al subir."; }
});

document.getElementById("assistantForm").addEventListener("submit", async e => {
  e.preventDefault();
  const reply = document.getElementById("aiReply");
  reply.textContent = "VAMPI AI está procesando tu consulta…";
  try {
    const response = await fetch("/api/assistant", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: document.getElementById("prompt").value })
    });
    const data = await response.json();
    reply.textContent = data.answer || data.error || "No se pudo procesar.";
    if (data.nextStep) reply.textContent += " " + data.nextStep;
  } catch { reply.textContent = "No se pudo conectar con el servidor."; }
});

document.getElementById("reportForm").addEventListener("submit", async e => {
  e.preventDefault();
  const out = document.getElementById("reportMessageStatus");
  try {
    const response = await fetch("/api/report", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: document.getElementById("reportType").value,
        message: document.getElementById("reportMessage").value
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    out.textContent = data.message;
    e.target.reset();
  } catch (err) { out.textContent = err.message || "No se pudo enviar el reporte."; }
});
